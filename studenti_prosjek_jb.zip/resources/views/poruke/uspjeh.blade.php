 @if(session('status'))
        <div class="success">
            {{ session('status') }}
        </div>
    @endif