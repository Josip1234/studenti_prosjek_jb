@include('layouts/header')
 
    <main>
      @include('layouts/navigation')
        <section>
            <h2>Dobrodošli</h2>
            <p>Ova aplikacija prikazuje popis studenata. Mogu se unositi studenti, brisati i editirati.</p>
            <p>Može se vidjeti i individualna statistika pojedinog studenta</p>
        </section>

    </main>
@include('layouts/footer')