    <aside>
            <h3>Izbronik</h3>
            <ul>
                <li><a href="{{ route('pocetna') }}">Početna</a></li>
                <li><a href="{{ route('studenti.unos') }}">Unos studenata</a></li>
                <li><a href="{{ route('studenti.popis') }}">Popis svih studenata</a></li>
            </ul>
        </aside>