
<!DOCTYPE html>
<html lang="hr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $__env->yieldContent('title','Studenti - početna'); ?></title>
    <link rel="stylesheet" href="/style/style.css">
</head>
<body>
    <header>
     
        <h1> Evidencija studenata i njihov prosjek</h1>
    </header><?php /**PATH C:\Users\Korisnik\Desktop\Xampp server 8.2.12\www\laravel\vjezba\studenti_prosjek_jb\resources\views/layouts/header.blade.php ENDPATH**/ ?>