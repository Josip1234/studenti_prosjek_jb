<?php $__env->startSection('content'); ?>
<?php 
use Carbon\Carbon;
?>

<table>
    <thead>
        <tr>
            <th>Broj</th>
            <th>Ime</th>
            <th>Prezime</th>
            <th>Status</th>
            <th>Godište</th>
            <th>Prosjek</th>
            <th>Datum upisa</th>
            <th>Akcije</th>
        </tr>
    </thead>
    <tbody>
        <?php
        $id = 0;
        ?> 
        <?php $__currentLoopData = $studenti; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $st): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
        <?php 
        $id++;
        ?> 
        <tr>
            <td><?php echo e($id); ?></td>
            <td><?php echo e($st->ime); ?></td>
            <td><?php echo e($st->prezime); ?></td>
            <td><?php echo e($st->status); ?></td>
             <td><?php echo e($st->godiste); ?></td>
            <td><?php echo e(number_format($st->prosjek,2,".",",")); ?></td>
            <td><?php echo e(Carbon::parse($st->created_at)->format('d.m.Y')); ?></td>
            <td><a href="<?php echo e(route("studenti.azuriranje",$st)); ?>">Ažuriraj</a>
                  <form method="POST" action="<?php echo e(route('studenti.delete', $st)); ?>"
                              class="inline"
                              onsubmit="return confirm('Obrisati studenta?');">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('DELETE'); ?>
                            <button class=".form-box button button:hover">Briši</button>
                        </form>
        </td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <tfoot>
           <tr>
                <td>Broj redovnih studenata:</td>
                <td> <?php echo e($brojRedovnih); ?>   </td>
                <td>Broj izvanrednih studenata </td>
                <td><?php echo e($brojVanrednih); ?></td>
                 <td>Prosječna ocjena </td>
                 <?php 
                 $pr_formatted=number_format($prosjek,2,".",",");
                 ?> 
                <td ><?php echo e($pr_formatted); ?></td>
                <td>Ocjena:</td>
                 <td>
                    <?php if($pr_formatted>=4.50): ?>
                       Odličan(5)
                    <?php elseif($pr_formatted<4.50 && $pr_formatted>=3.50): ?>
                        Vrlo dobar(4)
                    <?php elseif($pr_formatted<3.50 && $pr_formatted>=2.50): ?>
                        Dobar(3)
                    <?php elseif($pr_formatted<2.50 && $pr_formatted>=1.50): ?>
                        Dovoljan(2)
                    <?php else: ?> 
                        Nedovoljan(1)
                    <?php endif; ?>
                 </td>
                 </tr>
        </tfoot>
    </tbody>
    
</table>
<?php echo e($studenti->links()); ?>

<?php $__env->stopSection(); ?>

<?php /**PATH C:\Users\Korisnik\Desktop\Xampp server 8.2.12\www\laravel\vjezba\studenti_prosjek_jb\resources\views/liste_studenata/listaspag.blade.php ENDPATH**/ ?>