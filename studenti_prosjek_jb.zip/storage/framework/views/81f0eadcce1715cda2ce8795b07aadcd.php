<?php echo $__env->make('layouts/header', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
 
    <main>
      <?php echo $__env->make('layouts/navigation', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
        <section>
            <h2>Dobrodošli</h2>
            <p>Ova aplikacija prikazuje popis studenata. Mogu se unositi studenti, brisati i editirati.</p>
            <p>Može se vidjeti i individualna statistika pojedinog studenta</p>
        </section>

    </main>
<?php echo $__env->make('layouts/footer', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\Korisnik\Desktop\Xampp server 8.2.12\www\laravel\vjezba\studenti_prosjek_jb\resources\views/home.blade.php ENDPATH**/ ?>