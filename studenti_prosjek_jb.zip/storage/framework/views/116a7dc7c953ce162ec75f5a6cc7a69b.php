 <?php if(session('status')): ?>
        <div class="success">
            <?php echo e(session('status')); ?>

        </div>
    <?php endif; ?><?php /**PATH C:\Users\Korisnik\Desktop\Xampp server 8.2.12\www\laravel\vjezba\studenti_prosjek_jb\resources\views/poruke/uspjeh.blade.php ENDPATH**/ ?>