    <aside>
            <h3>Izbronik</h3>
            <ul>
                <li><a href="<?php echo e(route('pocetna')); ?>">Početna</a></li>
                <li><a href="<?php echo e(route('studenti.unos')); ?>">Unos studenata</a></li>
                <li><a href="<?php echo e(route('studenti.popis')); ?>">Popis svih studenata</a></li>
            </ul>
        </aside><?php /**PATH C:\Users\Korisnik\Desktop\Xampp server 8.2.12\www\laravel\vjezba\studenti_prosjek_jb\resources\views/layouts/navigation.blade.php ENDPATH**/ ?>