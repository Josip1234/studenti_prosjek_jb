<?php echo $__env->make('layouts/header', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

<main>
    <?php echo $__env->make('layouts/navigation', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
       <?php echo $__env->make('poruke/uspjeh', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    <?php echo $__env->make('liste_studenata/listaspag', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>


    
    <section>
         <?php echo $__env->yieldContent('content'); ?>
        
    </section>
          

</main>
<?php echo $__env->make('layouts/footer', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\Korisnik\Desktop\Xampp server 8.2.12\www\laravel\vjezba\studenti_prosjek_jb\resources\views/studenti/popis.blade.php ENDPATH**/ ?>